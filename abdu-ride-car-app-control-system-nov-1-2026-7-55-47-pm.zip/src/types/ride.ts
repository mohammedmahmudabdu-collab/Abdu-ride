/**
 * ABDU RIDE - Domain Models & Types
 */

export type ServiceTier = 'standard' | 'comfort' | 'minibus' | 'vip';

export interface LocationPoint {
  id: string;
  nameEn: string;
  nameAm: string;
  area: string;
  lat: number;
  lng: number;
}

export type RideStatus =
  | 'idle'
  | 'searching'
  | 'accepted'
  | 'arriving'
  | 'arrived'
  | 'in_progress'
  | 'completed'
  | 'cancelled';

export interface RideRequest {
  id: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  pickup: LocationPoint;
  destination: LocationPoint;
  tier: ServiceTier;
  fareEtb: number;
  distanceKm: number;
  durationMinutes: number;
  pin: string;
  status: RideStatus;
  driverId?: string;
  driverName?: string;
  driverPhone?: string;
  driverPlate?: string;
  driverVehicle?: string;
  driverRating?: number;
  driverAvatar?: string;
  paymentMethod: 'telebirr' | 'cbe_birr' | 'cash';
  paymentStatus: 'pending' | 'paid';
  createdAt: number;
  acceptedAt?: number;
  startedAt?: number;
  completedAt?: number;
  cancelledAt?: number;
  cancelReason?: string;
  customerRating?: number;
  customerTip?: number;
  sosTriggered?: boolean;
}

export interface DriverState {
  id: string;
  name: string;
  nameAm: string;
  phone: string;
  avatar: string;
  isOnline: boolean;
  status: 'offline' | 'idle' | 'heading_pickup' | 'at_pickup' | 'on_trip';
  vehicle: {
    make: string;
    model: string;
    plate: string;
    color: string;
    year: string;
    tier: ServiceTier;
  };
  location: {
    lat: number;
    lng: number;
    heading: number;
  };
  currentRideId?: string;
  todayEarnings: number;
  totalTrips: number;
  acceptanceRate: number;
  rating: number;
  walletBalance: number;
}

export interface ChatMessage {
  id: string;
  rideId: string;
  sender: 'customer' | 'driver' | 'system';
  text: string;
  timestamp: string;
}

export interface VehicleOption {
  tier: ServiceTier;
  nameEn: string;
  nameAm: string;
  subEn: string;
  subAm: string;
  capacity: number;
  baseFare: number;
  perKmRate: number;
  icon: string;
}

export type AppViewMode = 'split' | 'customer' | 'driver' | 'dispatch';
export type Language = 'en' | 'am';
