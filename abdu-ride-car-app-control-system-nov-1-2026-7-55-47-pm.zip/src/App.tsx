/**
 * ABDU RIDE - Car App Control System
 * Dual Phone Simulation & Fleet Dispatch Center
 */

import React from 'react';
import { RideControlProvider, useRideControl } from './context/RideControlContext';
import { AppHeader } from './components/AppHeader';
import { DualSimStudio } from './components/DualSimStudio';
import { CustomerApp } from './components/CustomerApp';
import { DriverApp } from './components/DriverApp';
import { DispatchControlCenter } from './components/DispatchControlCenter';

function MainContent() {
  const { viewMode } = useRideControl();

  return (
    <main className="flex-1 flex flex-col overflow-hidden relative">
      {viewMode === 'split' && <DualSimStudio />}

      {viewMode === 'customer' && (
        <div className="flex-1 flex items-center justify-center bg-slate-950 p-2 sm:p-4 overflow-hidden">
          <div className="w-full max-w-[430px] h-full max-h-[820px] bg-slate-900 rounded-[36px] p-2.5 shadow-2xl border-2 border-slate-800 flex flex-col overflow-hidden">
            <div className="w-full h-full rounded-[28px] overflow-hidden flex flex-col bg-slate-950">
              <CustomerApp />
            </div>
          </div>
        </div>
      )}

      {viewMode === 'driver' && (
        <div className="flex-1 flex items-center justify-center bg-slate-950 p-2 sm:p-4 overflow-hidden">
          <div className="w-full max-w-[430px] h-full max-h-[820px] bg-slate-900 rounded-[36px] p-2.5 shadow-2xl border-2 border-slate-800 flex flex-col overflow-hidden">
            <div className="w-full h-full rounded-[28px] overflow-hidden flex flex-col bg-slate-950">
              <DriverApp />
            </div>
          </div>
        </div>
      )}

      {viewMode === 'dispatch' && <DispatchControlCenter />}
    </main>
  );
}

export default function App() {
  return (
    <RideControlProvider>
      <div className="flex flex-col h-screen w-screen bg-slate-950 text-slate-100 font-sans overflow-hidden">
        <AppHeader />
        <MainContent />
      </div>
    </RideControlProvider>
  );
}
