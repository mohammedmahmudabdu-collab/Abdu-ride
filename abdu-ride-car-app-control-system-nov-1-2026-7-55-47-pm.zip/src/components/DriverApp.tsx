import React, { useState, useEffect } from 'react';
import {
  Power,
  Navigation,
  Compass,
  Phone,
  MessageSquare,
  ShieldCheck,
  CheckCircle,
  Clock,
  Wallet,
  ArrowUpRight,
  TrendingUp,
  Award,
  DollarSign,
  AlertCircle,
  KeyRound,
  X,
  Send,
  Car,
} from 'lucide-react';
import { useRideControl } from '../context/RideControlContext';
import { translations } from '../utils/i18n';
import { MapComponent } from './MapComponent';

interface DriverAppProps {
  inSplitView?: boolean;
}

export const DriverApp: React.FC<DriverAppProps> = ({ inSplitView = false }) => {
  const {
    language,
    currentDriver,
    toggleDriverOnline,
    activeRide,
    driverAcceptRide,
    driverDeclineRide,
    driverMarkArrived,
    driverStartTrip,
    driverCompleteTrip,
    withdrawTelebirr,
    chatMessages,
    sendChatMessage,
  } = useRideControl();

  const t = translations[language];

  const [activeTab, setActiveTab] = useState<'drive' | 'wallet' | 'profile'>('drive');
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState(false);
  const [showPinModal, setShowPinModal] = useState(false);
  const [acceptTimer, setAcceptTimer] = useState(15);
  const [chatOpen, setChatOpen] = useState(false);
  const [chatInput, setChatInput] = useState('');
  const [withdrawAmount, setWithdrawAmount] = useState('1000');
  const [payoutSuccess, setPayoutSuccess] = useState(false);

  const hasIncomingRequest =
    currentDriver.isOnline &&
    activeRide &&
    activeRide.status === 'searching' &&
    (!activeRide.driverId || activeRide.driverId === currentDriver.id);

  // Accept countdown timer
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (hasIncomingRequest) {
      setAcceptTimer(15);
      interval = setInterval(() => {
        setAcceptTimer((prev) => {
          if (prev <= 1) {
            clearInterval(interval);
            driverDeclineRide(currentDriver.id);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [hasIncomingRequest]);

  const handleStartTripWithPin = (e: React.FormEvent) => {
    e.preventDefault();
    const success = driverStartTrip(pinInput);
    if (success) {
      setPinError(false);
      setShowPinModal(false);
      setPinInput('');
    } else {
      setPinError(true);
    }
  };

  const handleWithdraw = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(withdrawAmount);
    if (!amt || amt <= 0) return;
    const ok = withdrawTelebirr(currentDriver.id, amt);
    if (ok) {
      setPayoutSuccess(true);
      setTimeout(() => setPayoutSuccess(false), 3000);
    }
  };

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    sendChatMessage('driver', chatInput);
    setChatInput('');
  };

  return (
    <div className={`relative flex flex-col h-full bg-slate-950 text-slate-100 overflow-hidden ${inSplitView ? 'border border-slate-800 rounded-3xl shadow-2xl' : ''}`}>
      {/* Driver Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-slate-900 border-b border-slate-800 z-20">
        <div className="flex items-center gap-2.5">
          <img
            src={currentDriver.avatar}
            alt={currentDriver.name}
            className="w-8 h-8 rounded-full object-cover border border-amber-400"
          />
          <div>
            <div className="text-xs font-bold text-white flex items-center gap-1">
              <span>{language === 'am' ? currentDriver.nameAm : currentDriver.name}</span>
              <span className="text-[10px] text-amber-400 font-normal">★ {currentDriver.rating}</span>
            </div>
            <div className="text-[10px] text-slate-400 font-mono">
              {currentDriver.vehicle.plate} · {currentDriver.vehicle.make}
            </div>
          </div>
        </div>

        {/* Online / Offline Tactile Toggle */}
        <button
          onClick={() => toggleDriverOnline(currentDriver.id)}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all shadow-md cursor-pointer ${
            currentDriver.isOnline
              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 hover:bg-emerald-500/30'
              : 'bg-rose-500/20 text-rose-400 border border-rose-500/40 hover:bg-rose-500/30'
          }`}
        >
          <Power className="w-3.5 h-3.5" />
          <span>{currentDriver.isOnline ? t.online : t.offline}</span>
        </button>
      </div>

      {/* Driver Navigation Tabs */}
      <div className="flex items-center justify-around bg-slate-900/60 border-b border-slate-800/80 px-2 py-1 text-xs">
        <button
          onClick={() => setActiveTab('drive')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
            activeTab === 'drive' ? 'bg-amber-400 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
          }`}
        >
          {language === 'am' ? 'የስራ መስኮት' : 'Live HUD'}
        </button>
        <button
          onClick={() => setActiveTab('wallet')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors flex items-center gap-1 ${
            activeTab === 'wallet' ? 'bg-amber-400 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
          }`}
        >
          <Wallet className="w-3.5 h-3.5" />
          <span>{currentDriver.walletBalance} {t.birrSymbol}</span>
        </button>
        <button
          onClick={() => setActiveTab('profile')}
          className={`px-3 py-1.5 rounded-lg font-medium transition-colors ${
            activeTab === 'profile' ? 'bg-amber-400 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
          }`}
        >
          {language === 'am' ? 'መረጃዎች' : 'Stats & Car'}
        </button>
      </div>

      {/* Tab 1: DRIVE HUD & MAP */}
      {activeTab === 'drive' && (
        <div className="relative flex-1 flex flex-col overflow-hidden">
          {/* Map display */}
          <div className="relative flex-1 w-full bg-slate-950">
            <MapComponent
              focusedDriverId={currentDriver.id}
              showAllDrivers={false}
              pickupPoint={activeRide?.status !== 'idle' ? activeRide?.pickup : null}
              dropoffPoint={activeRide?.status !== 'idle' ? activeRide?.destination : null}
            />

            {/* Offline Shield Banner */}
            {!currentDriver.isOnline && (
              <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-xs flex flex-col items-center justify-center p-6 text-center z-[400]">
                <div className="w-14 h-14 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center text-rose-400 mb-3">
                  <Power className="w-7 h-7" />
                </div>
                <h3 className="text-base font-bold text-white mb-1">
                  {language === 'am' ? 'ስራ አልጀመሩም (ኦፍላይን)' : 'You are currently Offline'}
                </h3>
                <p className="text-xs text-slate-400 max-w-xs mb-4">
                  {t.offlinePrompt}
                </p>
                <button
                  onClick={() => toggleDriverOnline(currentDriver.id)}
                  className="px-6 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl text-xs transition-colors shadow-lg shadow-emerald-500/20 cursor-pointer"
                >
                  {t.goOnline}
                </button>
              </div>
            )}

            {/* Online Idle Radar Banner */}
            {currentDriver.isOnline && !activeRide && (
              <div className="absolute top-3 left-3 right-3 z-[400] bg-slate-900/90 backdrop-blur-md border border-slate-700/80 p-3 rounded-2xl shadow-xl flex items-center gap-3">
                <div className="relative flex items-center justify-center w-8 h-8">
                  <div className="absolute w-8 h-8 rounded-full bg-emerald-400/20 animate-ping" />
                  <div className="w-3.5 h-3.5 rounded-full bg-emerald-400 shadow-md shadow-emerald-400" />
                </div>
                <div className="flex-1">
                  <div className="text-xs font-bold text-white">{t.waitingForRequests}</div>
                  <div className="text-[10px] text-slate-400">Addis Ababa GPS telemetry active</div>
                </div>
              </div>
            )}
          </div>

          {/* Incoming Ride Request Modal (with sound & 15s timer) */}
          {hasIncomingRequest && (
            <div className="absolute inset-x-3 bottom-4 z-[500] bg-slate-900 border-2 border-amber-400 rounded-2xl p-4 shadow-2xl animate-in slide-in-from-bottom duration-300">
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <span className="text-xl">🔔</span>
                  <div>
                    <div className="text-xs font-black text-amber-400 uppercase tracking-wide">
                      {t.incomingRequest}
                    </div>
                    <div className="text-[10px] text-slate-400">
                      {activeRide.distanceKm} km · Est. {activeRide.durationMinutes} mins
                    </div>
                  </div>
                </div>
                {/* 15s Countdown Ring */}
                <div className="w-9 h-9 rounded-full bg-amber-400/10 border-2 border-amber-400 flex items-center justify-center font-mono font-bold text-amber-400 text-sm">
                  {acceptTimer}s
                </div>
              </div>

              {/* Ride Fare and Route */}
              <div className="my-3 space-y-2">
                <div className="flex items-center justify-between bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <span className="text-xs text-slate-300 font-medium">{t.estimatedEarnings}</span>
                  <span className="text-lg font-black text-emerald-400 font-mono">
                    {Math.round(activeRide.fareEtb * 0.85)} {t.birrSymbol}
                  </span>
                </div>

                <div className="text-xs space-y-1.5 px-1">
                  <div className="flex items-start gap-2">
                    <span className="text-emerald-400 font-bold mt-0.5">●</span>
                    <div className="truncate">
                      <span className="text-slate-400 text-[10px] uppercase block">{t.customerPickupAt}</span>
                      <span className="text-white font-medium">{activeRide.pickup.nameEn}</span>
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="text-rose-400 font-bold mt-0.5">●</span>
                    <div className="truncate">
                      <span className="text-slate-400 text-[10px] uppercase block">{t.customerDropoffAt}</span>
                      <span className="text-white font-medium">{activeRide.destination.nameEn}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 pt-1">
                <button
                  onClick={() => driverDeclineRide(currentDriver.id)}
                  className="w-1/3 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-xl text-xs transition-colors cursor-pointer"
                >
                  {t.declineTrip}
                </button>
                <button
                  onClick={() => driverAcceptRide(currentDriver.id)}
                  className="flex-1 py-2.5 bg-amber-400 hover:bg-amber-300 active:scale-[0.99] text-slate-950 font-black rounded-xl text-xs transition-all shadow-lg shadow-amber-400/25 flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <CheckCircle className="w-4 h-4" />
                  <span>{t.acceptTrip}</span>
                </button>
              </div>
            </div>
          )}

          {/* Active Ride Driver Control HUD (Arriving / At Pickup / On Trip) */}
          {activeRide &&
            activeRide.status !== 'searching' &&
            activeRide.status !== 'completed' &&
            activeRide.driverId === currentDriver.id && (
              <div className="bg-slate-900 border-t border-slate-800 p-4 shadow-2xl z-20 space-y-3">
                {/* Stage 1: En Route to Pickup */}
                {activeRide.status === 'arriving' && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                      <div>
                        <div className="text-[10px] text-amber-400 uppercase tracking-wider font-bold">
                          {t.navToPickup}
                        </div>
                        <div className="text-xs font-bold text-white truncate max-w-[200px]">
                          {activeRide.pickup.nameEn}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-[10px] text-slate-400">Distance</div>
                        <div className="text-xs font-mono font-bold text-slate-200">~600 meters</div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between bg-slate-950/60 p-2.5 rounded-xl border border-slate-800">
                      <div>
                        <div className="text-xs font-bold text-white">{activeRide.customerName}</div>
                        <div className="text-[10px] text-slate-400 font-mono">{activeRide.customerPhone}</div>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => setChatOpen(true)}
                          className="p-2 bg-slate-800 hover:bg-slate-700 text-amber-400 rounded-xl"
                        >
                          <MessageSquare className="w-4 h-4" />
                        </button>
                        <a
                          href={`tel:${activeRide.customerPhone}`}
                          className="p-2 bg-emerald-600/20 text-emerald-400 rounded-xl border border-emerald-500/30"
                        >
                          <Phone className="w-4 h-4" />
                        </a>
                      </div>
                    </div>

                    <button
                      onClick={driverMarkArrived}
                      className="w-full py-3 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black rounded-xl text-xs transition-all shadow-md shadow-amber-400/20 flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Navigation className="w-4 h-4" />
                      <span>{t.markArrived}</span>
                    </button>
                  </div>
                )}

                {/* Stage 2: At Pickup -> Verify 4-Digit Passenger PIN */}
                {activeRide.status === 'arrived' && (
                  <div className="space-y-3">
                    <div className="p-3 bg-amber-400/10 border border-amber-400/30 rounded-xl text-center">
                      <div className="text-xs font-bold text-amber-400 mb-0.5">{t.waitingPassenger}</div>
                      <div className="text-[11px] text-slate-300">
                        Ask passenger for the 4-digit PIN shown on their phone screen.
                      </div>
                    </div>

                    <form onSubmit={handleStartTripWithPin} className="space-y-2">
                      <div className="relative">
                        <KeyRound className="absolute left-3 top-2.5 w-4 h-4 text-amber-400" />
                        <input
                          type="text"
                          value={pinInput}
                          onChange={(e) => {
                            setPinInput(e.target.value);
                            setPinError(false);
                          }}
                          placeholder={t.enterPinToStart}
                          maxLength={4}
                          className="w-full text-center tracking-[0.5em] text-lg font-mono font-bold bg-slate-950 border border-slate-700 rounded-xl py-2 pl-9 pr-3 text-white focus:outline-none focus:border-amber-400"
                        />
                      </div>

                      {pinError && (
                        <p className="text-[11px] text-rose-400 text-center font-medium">
                          {t.invalidPinMsg} (Demo PIN is {activeRide.pin})
                        </p>
                      )}

                      <div className="flex gap-2">
                        <button
                          type="button"
                          onClick={() => setPinInput(activeRide.pin)}
                          className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-amber-300 text-[11px] font-semibold rounded-xl"
                        >
                          Auto PIN ({activeRide.pin})
                        </button>
                        <button
                          type="submit"
                          className="flex-1 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black rounded-xl text-xs transition-all shadow-md shadow-emerald-500/20 cursor-pointer"
                        >
                          {t.startTripBtn}
                        </button>
                      </div>
                    </form>
                  </div>
                )}

                {/* Stage 3: On Trip -> Driving to Destination */}
                {activeRide.status === 'in_progress' && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                      <div>
                        <div className="text-[10px] text-emerald-400 uppercase tracking-wider font-bold">
                          {t.navToDest}
                        </div>
                        <div className="text-xs font-bold text-white truncate max-w-[200px]">
                          {activeRide.destination.nameEn}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-[10px] text-slate-400">Meter Fare</div>
                        <div className="text-xs font-mono font-bold text-emerald-400">
                          {activeRide.fareEtb} {t.birrSymbol}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-xs text-slate-400 bg-slate-950/60 p-2 rounded-xl">
                      <span>Speed: 38 km/h</span>
                      <span>Traffic: Moderate</span>
                      <span>Payment: {activeRide.paymentMethod.toUpperCase()}</span>
                    </div>

                    <button
                      onClick={driverCompleteTrip}
                      className="w-full py-3 bg-emerald-500 hover:bg-emerald-400 active:scale-[0.99] text-slate-950 font-black rounded-xl text-xs transition-all shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <CheckCircle className="w-4 h-4" />
                      <span>{t.completeTripBtn}</span>
                    </button>
                  </div>
                )}
              </div>
            )}

          {/* In-App Chat Drawer for Driver */}
          {chatOpen && (
            <div className="absolute inset-0 z-[600] bg-slate-950/95 backdrop-blur-md flex flex-col p-4 animate-in fade-in duration-200">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="text-xs font-bold text-white">
                  Passenger Chat: {activeRide?.customerName}
                </div>
                <button onClick={() => setChatOpen(false)} className="p-1 rounded text-slate-400 hover:text-white">
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto space-y-2 py-3">
                {chatMessages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${
                      msg.sender === 'driver' ? 'items-end' : msg.sender === 'customer' ? 'items-start' : 'items-center'
                    }`}
                  >
                    {msg.sender === 'system' ? (
                      <div className="text-[10px] text-amber-400/90 bg-amber-400/10 px-2 py-1 rounded font-mono">
                        {msg.text}
                      </div>
                    ) : (
                      <div
                        className={`max-w-[78%] px-3 py-2 rounded-2xl text-xs ${
                          msg.sender === 'driver'
                            ? 'bg-amber-400 text-slate-950 font-medium rounded-br-none'
                            : 'bg-slate-800 text-white rounded-bl-none'
                        }`}
                      >
                        {msg.text}
                        <div className="text-[9px] opacity-70 text-right mt-0.5">{msg.timestamp}</div>
                      </div>
                    )}
                  </div>
                ))}
              </div>

              <form onSubmit={handleSendChat} className="flex gap-2 pt-2 border-t border-slate-800">
                <input
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  placeholder="Reply to passenger..."
                  className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
                <button
                  type="submit"
                  className="p-2 bg-amber-400 hover:bg-amber-300 text-slate-950 rounded-xl"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </div>
          )}
        </div>
      )}

      {/* Tab 2: WALLET & TELEBIRR WITHDRAWAL */}
      {activeTab === 'wallet' && (
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-950">
          <div className="bg-gradient-to-br from-slate-900 to-slate-900/90 border border-slate-800 rounded-2xl p-4">
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
              <span>{t.walletTitle}</span>
              <span className="text-amber-400 font-mono">Telebirr Connected</span>
            </div>
            <div className="text-2xl font-black text-white font-mono">
              {currentDriver.walletBalance} <span className="text-amber-400 text-base">{t.birrSymbol}</span>
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              Available for immediate bank or Telebirr transfer.
            </div>
          </div>

          {/* Quick Telebirr Cashout Form */}
          <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-4 space-y-3">
            <div className="text-xs font-bold text-white flex items-center justify-between">
              <span>{t.withdrawTelebirr}</span>
              <span className="text-[10px] text-slate-400">Phone: {currentDriver.phone}</span>
            </div>

            <form onSubmit={handleWithdraw} className="space-y-3">
              <div>
                <label className="text-[11px] text-slate-400 mb-1 block">Payout Amount (ETB)</label>
                <input
                  type="number"
                  value={withdrawAmount}
                  onChange={(e) => setWithdrawAmount(e.target.value)}
                  min={100}
                  max={currentDriver.walletBalance}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-amber-400"
                />
              </div>

              {payoutSuccess && (
                <div className="p-2.5 bg-emerald-500/20 border border-emerald-500/40 rounded-xl text-emerald-400 text-xs text-center font-medium">
                  {t.withdrawnSuccess}
                </div>
              )}

              <button
                type="submit"
                disabled={currentDriver.walletBalance < 100}
                className="w-full py-2.5 bg-amber-400 hover:bg-amber-300 disabled:opacity-40 text-slate-950 font-bold rounded-xl text-xs transition-colors cursor-pointer"
              >
                Request Telebirr Cashout
              </button>
            </form>
          </div>

          {/* Earnings summary */}
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-800">
              <div className="text-slate-400 text-[10px] uppercase font-semibold">Today's Earnings</div>
              <div className="text-base font-bold text-emerald-400 font-mono mt-0.5">
                {currentDriver.todayEarnings} {t.birrSymbol}
              </div>
            </div>
            <div className="bg-slate-900/60 p-3 rounded-xl border border-slate-800">
              <div className="text-slate-400 text-[10px] uppercase font-semibold">All Time Trips</div>
              <div className="text-base font-bold text-white font-mono mt-0.5">
                {currentDriver.totalTrips}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: STATS & VEHICLE INSPECTION */}
      {activeTab === 'profile' && (
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-950 text-xs">
          {/* Driver identity */}
          <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800 flex items-center gap-3">
            <img
              src={currentDriver.avatar}
              alt="Avatar"
              className="w-14 h-14 rounded-2xl object-cover border-2 border-amber-400"
            />
            <div>
              <div className="text-sm font-bold text-white">{currentDriver.name}</div>
              <div className="text-slate-400 text-[11px] font-mono">{currentDriver.phone}</div>
              <div className="mt-1 flex items-center gap-2">
                <span className="text-amber-400 font-bold">★ {currentDriver.rating}</span>
                <span className="text-slate-500">·</span>
                <span className="text-emerald-400">{currentDriver.acceptanceRate}% Acceptance</span>
              </div>
            </div>
          </div>

          {/* Vehicle specs */}
          <div className="bg-slate-900 p-4 rounded-2xl border border-slate-800 space-y-2.5">
            <div className="text-xs font-bold text-white flex items-center gap-1.5">
              <Car className="w-4 h-4 text-amber-400" />
              <span>Assigned Vehicle</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div>
                <span className="text-slate-500 block">Make & Model</span>
                <span className="text-white font-medium">{currentDriver.vehicle.make} {currentDriver.vehicle.model}</span>
              </div>
              <div>
                <span className="text-slate-500 block">License Plate</span>
                <span className="text-amber-400 font-mono font-bold">{currentDriver.vehicle.plate}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Color</span>
                <span className="text-white">{currentDriver.vehicle.color}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Service Tier</span>
                <span className="text-white uppercase font-bold">{currentDriver.vehicle.tier}</span>
              </div>
            </div>
          </div>

          <div className="bg-slate-900/50 p-3 rounded-xl border border-slate-800 text-slate-400 text-[11px] space-y-1">
            <div className="text-white font-semibold">Regulatory Compliance</div>
            <div>Addis Ababa Transport Bureau Taxi License: Active</div>
            <div>Vehicle Safety Inspection: Passed</div>
            <div>Telebirr Merchant Integration: Verified</div>
          </div>
        </div>
      )}
    </div>
  );
};
