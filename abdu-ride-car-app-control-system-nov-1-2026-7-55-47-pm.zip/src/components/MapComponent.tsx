import React, { useEffect, useRef } from 'react';
import L from 'leaflet';
import { useRideControl } from '../context/RideControlContext';
import { DriverState, LocationPoint } from '../types/ride';

interface MapComponentProps {
  height?: string;
  interactive?: boolean;
  onSelectCoordinate?: (lat: number, lng: number) => void;
  showAllDrivers?: boolean;
  focusedDriverId?: string;
  pickupPoint?: LocationPoint | null;
  dropoffPoint?: LocationPoint | null;
  zoomLevel?: number;
}

export const MapComponent: React.FC<MapComponentProps> = ({
  height = '100%',
  interactive = true,
  onSelectCoordinate,
  showAllDrivers = true,
  focusedDriverId,
  pickupPoint,
  dropoffPoint,
  zoomLevel = 13,
}) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const driverMarkersRef = useRef<Record<string, L.Marker>>({});
  const pickupMarkerRef = useRef<L.Marker | null>(null);
  const dropoffMarkerRef = useRef<L.Marker | null>(null);
  const polylineRef = useRef<L.Polyline | null>(null);

  const { drivers, activeRide } = useRideControl();

  // Create SVG Car Icon for Leaflet
  const createCarIcon = (color: string, heading: number, isLada: boolean = false) => {
    const ladaRoof = isLada
      ? `<rect x="15" y="8" width="10" height="4" rx="1" fill="#FFC400" stroke="#000" stroke-width="1"/>`
      : '';

    const svgHtml = `
      <div style="transform: rotate(${heading}deg); transform-origin: center; width: 40px; height: 40px; display: flex; align-items: center; justify-content: center; filter: drop-shadow(0 4px 6px rgba(0,0,0,0.3));">
        <svg viewBox="0 0 40 40" width="38" height="38">
          <!-- Car Body -->
          <rect x="10" y="6" width="20" height="28" rx="6" fill="${color}" stroke="#1e293b" stroke-width="2"/>
          <!-- Windshields -->
          <rect x="13" y="11" width="14" height="6" rx="2" fill="#38bdf8" opacity="0.9"/>
          <rect x="13" y="24" width="14" height="4" rx="1.5" fill="#38bdf8" opacity="0.8"/>
          <!-- Headlights -->
          <circle cx="13" cy="8" r="1.5" fill="#fef08a"/>
          <circle cx="27" cy="8" r="1.5" fill="#fef08a"/>
          <!-- Wheels -->
          <rect x="7" y="10" width="3" height="6" rx="1" fill="#0f172a"/>
          <rect x="30" y="10" width="3" height="6" rx="1" fill="#0f172a"/>
          <rect x="7" y="24" width="3" height="6" rx="1" fill="#0f172a"/>
          <rect x="30" y="24" width="3" height="6" rx="1" fill="#0f172a"/>
          ${ladaRoof}
        </svg>
      </div>
    `;

    return L.divIcon({
      html: svgHtml,
      className: 'custom-car-marker',
      iconSize: [40, 40],
      iconAnchor: [20, 20],
    });
  };

  const createPinIcon = (type: 'pickup' | 'dropoff') => {
    const isPickup = type === 'pickup';
    const bg = isPickup ? '#10b981' : '#ef4444';
    const text = isPickup ? 'P' : 'D';

    const svg = `
      <div style="position: relative; display: flex; flex-direction: column; align-items: center; filter: drop-shadow(0 4px 8px rgba(0,0,0,0.35));">
        <div style="background: ${bg}; color: white; width: 30px; height: 30px; border-radius: 50% 50% 50% 0; transform: rotate(-45deg); display: flex; align-items: center; justify-content: center; border: 2px solid white;">
          <span style="transform: rotate(45deg); font-weight: 800; font-size: 13px; font-family: sans-serif;">${text}</span>
        </div>
        <div style="width: 8px; height: 8px; border-radius: 50%; background: ${bg}; opacity: 0.6; margin-top: -2px; animation: ping 1.5s cubic-bezier(0, 0, 0.2, 1) infinite;"></div>
      </div>
    `;

    return L.divIcon({
      html: svg,
      className: 'custom-pin-marker',
      iconSize: [30, 42],
      iconAnchor: [15, 38],
    });
  };

  // Initialize Map
  useEffect(() => {
    if (!mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      // Default to Addis Ababa center (around Meskel Square / Kazanchis)
      const map = L.map(mapContainerRef.current, {
        center: [9.0102, 38.7617],
        zoom: zoomLevel,
        zoomControl: false,
        attributionControl: false,
        dragging: interactive,
        scrollWheelZoom: interactive,
        touchZoom: interactive,
      });

      // CartoDB Voyager tiles (clean, modern, road-centric)
      L.tileLayer('https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png', {
        maxZoom: 19,
        subdomains: 'abcd',
      }).addTo(map);

      // Add compact zoom control in top right
      if (interactive) {
        L.control.zoom({ position: 'topright' }).addTo(map);
      }

      map.on('click', (e: L.LeafletMouseEvent) => {
        if (onSelectCoordinate) {
          onSelectCoordinate(e.latlng.lat, e.latlng.lng);
        }
      });

      mapInstanceRef.current = map;
    }

    const map = mapInstanceRef.current;
    setTimeout(() => {
      map.invalidateSize();
    }, 200);

    return () => {
      // Keep map alive if component re-renders
    };
  }, []);

  // Update drivers on map
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    const driversToShow = showAllDrivers
      ? drivers
      : drivers.filter((d) => !focusedDriverId || d.id === focusedDriverId);

    // Remove old markers
    const currentDriverIds = new Set(driversToShow.map((d) => d.id));
    Object.keys(driverMarkersRef.current).forEach((id) => {
      if (!currentDriverIds.has(id)) {
        driverMarkersRef.current[id].remove();
        delete driverMarkersRef.current[id];
      }
    });

    // Update or add driver markers
    driversToShow.forEach((driver: DriverState) => {
      const color =
        driver.vehicle.tier === 'standard'
          ? '#2563eb' // Classic blue Addis lada
          : driver.vehicle.tier === 'comfort'
          ? '#eab308' // Gold
          : driver.vehicle.tier === 'minibus'
          ? '#059669' // Green minibus
          : '#0f172a'; // Black VIP

      const isLada = driver.vehicle.tier === 'standard';
      const icon = createCarIcon(color, driver.location.heading, isLada);

      if (driverMarkersRef.current[driver.id]) {
        driverMarkersRef.current[driver.id].setLatLng([driver.location.lat, driver.location.lng]);
        driverMarkersRef.current[driver.id].setIcon(icon);
      } else {
        const marker = L.marker([driver.location.lat, driver.location.lng], { icon }).addTo(map);
        marker.bindPopup(`
          <div style="font-family: sans-serif; font-size: 13px; line-height: 1.4;">
            <strong style="color: #0f172a; font-size: 14px;">${driver.name}</strong><br/>
            <span style="color: #64748b;">${driver.vehicle.model}</span><br/>
            <span style="color: #f59e0b; font-weight: bold;">★ ${driver.rating}</span> · 
            <span style="color: ${driver.isOnline ? '#10b981' : '#94a3b8'}; font-weight: bold;">
              ${driver.isOnline ? 'Online' : 'Offline'}
            </span>
          </div>
        `);
        driverMarkersRef.current[driver.id] = marker;
      }
    });
  }, [drivers, showAllDrivers, focusedDriverId]);

  // Update Pickup & Dropoff Markers and Polyline Route
  useEffect(() => {
    const map = mapInstanceRef.current;
    if (!map) return;

    const currentPickup = pickupPoint || activeRide?.pickup;
    const currentDropoff = dropoffPoint || activeRide?.destination;

    // Pickup Marker
    if (currentPickup) {
      if (!pickupMarkerRef.current) {
        pickupMarkerRef.current = L.marker([currentPickup.lat, currentPickup.lng], {
          icon: createPinIcon('pickup'),
        }).addTo(map);
      } else {
        pickupMarkerRef.current.setLatLng([currentPickup.lat, currentPickup.lng]);
      }
      pickupMarkerRef.current.bindTooltip(currentPickup.nameEn, { permanent: false, direction: 'top' });
    } else if (pickupMarkerRef.current) {
      pickupMarkerRef.current.remove();
      pickupMarkerRef.current = null;
    }

    // Dropoff Marker
    if (currentDropoff) {
      if (!dropoffMarkerRef.current) {
        dropoffMarkerRef.current = L.marker([currentDropoff.lat, currentDropoff.lng], {
          icon: createPinIcon('dropoff'),
        }).addTo(map);
      } else {
        dropoffMarkerRef.current.setLatLng([currentDropoff.lat, currentDropoff.lng]);
      }
      dropoffMarkerRef.current.bindTooltip(currentDropoff.nameEn, { permanent: false, direction: 'top' });
    } else if (dropoffMarkerRef.current) {
      dropoffMarkerRef.current.remove();
      dropoffMarkerRef.current = null;
    }

    // Route Polyline
    if (polylineRef.current) {
      polylineRef.current.remove();
      polylineRef.current = null;
    }

    if (currentPickup && currentDropoff) {
      // Create a nice smooth path between pickup and dropoff
      // (Optional intermediate waypoint curve to feel like city streets)
      const midLat = (currentPickup.lat + currentDropoff.lat) / 2 + 0.003;
      const midLng = (currentPickup.lng + currentDropoff.lng) / 2 - 0.002;

      const pathCoords: [number, number][] = [
        [currentPickup.lat, currentPickup.lng],
        [midLat, midLng],
        [currentDropoff.lat, currentDropoff.lng],
      ];

      polylineRef.current = L.polyline(pathCoords, {
        color: '#eab308',
        weight: 5,
        opacity: 0.85,
        dashArray: activeRide?.status === 'arriving' ? '8, 8' : undefined,
      }).addTo(map);

      // Auto fit bounds
      try {
        const bounds = L.latLngBounds(pathCoords);
        map.fitBounds(bounds, { padding: [40, 40], maxZoom: 15 });
      } catch (err) {
        // ignore bounds fit error
      }
    }
  }, [pickupPoint, dropoffPoint, activeRide]);

  return (
    <div className="relative w-full h-full overflow-hidden" style={{ minHeight: '260px', height }}>
      <div ref={mapContainerRef} className="w-full h-full z-0 bg-slate-100" />
      {/* Map watermark / Attribution badge */}
      <div className="absolute bottom-2 left-2 z-[400] bg-white/80 backdrop-blur-xs px-2 py-0.5 rounded text-[10px] text-slate-500 font-mono shadow-xs pointer-events-none">
        Addis Ababa Live Map · ABDU GPS
      </div>
    </div>
  );
};
