import React from 'react';
import {
  Play,
  RotateCcw,
  Sparkles,
  ArrowRight,
  ShieldAlert,
  Smartphone,
  Navigation,
  CheckCircle2,
} from 'lucide-react';
import { useRideControl } from '../context/RideControlContext';
import { translations, ADDIS_LOCATIONS } from '../utils/i18n';
import { CustomerApp } from './CustomerApp';
import { DriverApp } from './DriverApp';

export const DualSimStudio: React.FC = () => {
  const {
    language,
    activeRide,
    quickDemoHail,
    driverAcceptRide,
    driverMarkArrived,
    driverStartTrip,
    driverCompleteTrip,
    triggerSOS,
    resetAll,
  } = useRideControl();

  const t = translations[language];

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 text-slate-100 overflow-y-auto">
      {/* Simulation Scenario Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-6 py-3 bg-slate-900 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-amber-400 text-slate-950 font-black flex items-center justify-center text-sm shadow-md shadow-amber-400/20">
            📱
          </div>
          <div>
            <div className="text-xs font-bold text-white flex items-center gap-1.5">
              <span>{t.dualSim}</span>
              <span className="text-[10px] text-amber-400 font-mono">Live Inter-App Sync</span>
            </div>
            <div className="text-[10px] text-slate-400">
              Hail on the Customer phone (Left) and accept on the Driver partner phone (Right)
            </div>
          </div>
        </div>

        {/* Quick Simulation Automation Steps */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          {!activeRide && (
            <button
              onClick={quickDemoHail}
              className="px-3 py-1.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold rounded-xl transition-all shadow-md shadow-amber-400/20 flex items-center gap-1.5 cursor-pointer"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>1. Quick Hail (Meskel Sq → Bole)</span>
            </button>
          )}

          {activeRide?.status === 'searching' && (
            <button
              onClick={() => driverAcceptRide()}
              className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer animate-pulse"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>2. Driver Accept Ride</span>
            </button>
          )}

          {activeRide?.status === 'arriving' && (
            <button
              onClick={driverMarkArrived}
              className="px-3 py-1.5 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Navigation className="w-3.5 h-3.5" />
              <span>3. Mark Driver Arrived</span>
            </button>
          )}

          {activeRide?.status === 'arrived' && (
            <button
              onClick={() => driverStartTrip(activeRide.pin)}
              className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>4. Verify PIN ({activeRide.pin}) & Start</span>
            </button>
          )}

          {activeRide?.status === 'in_progress' && (
            <button
              onClick={driverCompleteTrip}
              className="px-3 py-1.5 bg-purple-500 hover:bg-purple-400 text-white font-bold rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>5. Complete Trip & Collect Fare</span>
            </button>
          )}

          {activeRide && (
            <button
              onClick={triggerSOS}
              className="px-3 py-1.5 bg-rose-950/60 hover:bg-rose-900 border border-rose-800 text-rose-300 font-bold rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>Test SOS</span>
            </button>
          )}

          <button
            onClick={resetAll}
            title="Reset All"
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Dual Mobile Viewports Container */}
      <div className="flex-1 flex flex-col xl:flex-row items-center justify-center p-4 md:p-6 gap-6 md:gap-10">
        {/* Left: Customer App Phone Mockup */}
        <div className="w-full max-w-[390px] h-[720px] max-h-[82vh] bg-slate-900 rounded-[42px] p-3 shadow-2xl border-4 border-slate-800 ring-1 ring-slate-700/50 flex flex-col relative overflow-hidden">
          {/* Phone Speaker Notch */}
          <div className="absolute top-4 left-1/2 -translate-x-1/2 w-28 h-4 bg-slate-950 rounded-full z-40 flex items-center justify-center">
            <div className="w-3 h-3 rounded-full bg-slate-900 border border-slate-800 mr-2" />
            <div className="w-10 h-1 bg-slate-800 rounded-full" />
          </div>

          <div className="w-full h-full rounded-[32px] overflow-hidden flex flex-col pt-3 bg-slate-950">
            <CustomerApp inSplitView={true} />
          </div>
        </div>

        {/* Center Connection Indicator for Desktop */}
        <div className="hidden xl:flex flex-col items-center justify-center gap-2 text-slate-500">
          <div className="w-px h-16 bg-slate-800" />
          <div className="w-10 h-10 rounded-full bg-slate-900 border border-slate-700 flex items-center justify-center text-amber-400 font-mono text-xs shadow-lg">
            ⚡
          </div>
          <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400">Synced</span>
          <div className="w-px h-16 bg-slate-800" />
        </div>

        {/* Right: Driver Partner Phone Mockup */}
        <div className="w-full max-w-[390px] h-[720px] max-h-[82vh] bg-slate-900 rounded-[42px] p-3 shadow-2xl border-4 border-slate-800 ring-1 ring-slate-700/50 flex flex-col relative overflow-hidden">
          {/* Phone Speaker Notch */}
          <div className="absolute top-4 left-1/2 -translate-x-1/2 w-28 h-4 bg-slate-950 rounded-full z-40 flex items-center justify-center">
            <div className="w-3 h-3 rounded-full bg-slate-900 border border-slate-800 mr-2" />
            <div className="w-10 h-1 bg-slate-800 rounded-full" />
          </div>

          <div className="w-full h-full rounded-[32px] overflow-hidden flex flex-col pt-3 bg-slate-950">
            <DriverApp inSplitView={true} />
          </div>
        </div>
      </div>
    </div>
  );
};
