import React from 'react';
import {
  Smartphone,
  Car,
  Radio,
  Volume2,
  VolumeX,
  Globe,
  Columns2,
  Sparkles,
} from 'lucide-react';
import { useRideControl } from '../context/RideControlContext';
import { translations } from '../utils/i18n';
import { AppViewMode, Language } from '../types/ride';

export const AppHeader: React.FC = () => {
  const {
    viewMode,
    setViewMode,
    language,
    setLanguage,
    soundEnabled,
    setSoundEnabled,
    activeRide,
    drivers,
  } = useRideControl();

  const t = translations[language];

  return (
    <header className="flex flex-wrap items-center justify-between gap-3 px-4 py-2.5 bg-slate-900 border-b border-slate-800 text-slate-100 select-none z-30">
      {/* Brand Identity */}
      <div className="flex items-center gap-2.5">
        <div className="w-9 h-9 rounded-xl bg-amber-400 text-slate-950 font-black flex items-center justify-center text-lg shadow-md shadow-amber-400/20">
          🚖
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className="text-sm font-black tracking-wider text-amber-400 font-mono">
              ABDU RIDE
            </span>
            <span className="text-[10px] text-slate-400 font-mono hidden sm:inline">
              Control Ecosystem
            </span>
          </div>
          <div className="text-[11px] text-slate-400">
            {language === 'am' ? 'የሹፌር፣ የደንበኛ እና የዲስፓች ሲስተም' : 'Driver App · Customer App · Dispatch Center'}
          </div>
        </div>
      </div>

      {/* Main Mode Switcher Tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-950 rounded-xl border border-slate-800">
        <button
          onClick={() => setViewMode('split')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
            viewMode === 'split'
              ? 'bg-amber-400 text-slate-950 shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Columns2 className="w-3.5 h-3.5" />
          <span className="hidden md:inline">{t.dualSim}</span>
          <span className="md:hidden">Dual</span>
        </button>

        <button
          onClick={() => setViewMode('customer')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
            viewMode === 'customer'
              ? 'bg-amber-400 text-slate-950 shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Smartphone className="w-3.5 h-3.5" />
          <span>{t.customer}</span>
        </button>

        <button
          onClick={() => setViewMode('driver')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
            viewMode === 'driver'
              ? 'bg-amber-400 text-slate-950 shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Car className="w-3.5 h-3.5" />
          <span>{t.driver}</span>
        </button>

        <button
          onClick={() => setViewMode('dispatch')}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
            viewMode === 'dispatch'
              ? 'bg-amber-400 text-slate-950 shadow-sm'
              : 'text-slate-400 hover:text-white hover:bg-slate-900'
          }`}
        >
          <Radio className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">{t.dispatch}</span>
          <span className="sm:hidden">Fleet</span>
        </button>
      </div>

      {/* Language, Audio and Live Status Controls */}
      <div className="flex items-center gap-2">
        {/* Language Switcher */}
        <button
          onClick={() => setLanguage(language === 'en' ? 'am' : 'en')}
          className="flex items-center gap-1 px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-medium transition-colors cursor-pointer"
          title="Switch language"
        >
          <Globe className="w-3.5 h-3.5 text-amber-400" />
          <span>{language === 'en' ? 'አማርኛ' : 'English'}</span>
        </button>

        {/* Sound Toggle */}
        <button
          onClick={() => setSoundEnabled(!soundEnabled)}
          className={`p-2 rounded-xl text-xs transition-colors border cursor-pointer ${
            soundEnabled
              ? 'bg-slate-800 text-amber-400 border-slate-700 hover:bg-slate-700'
              : 'bg-slate-950 text-slate-500 border-slate-800 hover:text-slate-300'
          }`}
          title={soundEnabled ? 'Sound alerts on' : 'Sound muted'}
        >
          {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
        </button>
      </div>
    </header>
  );
};
