import React, { useState } from 'react';
import {
  Search,
  MapPin,
  Phone,
  MessageSquare,
  ShieldAlert,
  Car,
  Clock,
  Navigation,
  Star,
  CheckCircle2,
  ChevronRight,
  LogOut,
  Send,
  X,
  CreditCard,
  DollarSign,
  AlertTriangle,
  RotateCcw,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { useRideControl } from '../context/RideControlContext';
import { translations, ADDIS_LOCATIONS } from '../utils/i18n';
import { ServiceTier, LocationPoint } from '../types/ride';
import { MapComponent } from './MapComponent';

interface CustomerAppProps {
  inSplitView?: boolean;
}

export const CustomerApp: React.FC<CustomerAppProps> = ({ inSplitView = false }) => {
  const {
    language,
    activeRide,
    createCustomerRide,
    cancelRide,
    rateAndFinishRide,
    sendChatMessage,
    chatMessages,
    triggerSOS,
    sosAlert,
  } = useRideControl();

  const t = translations[language];

  // Auth state (from Flutter starter prototype)
  const [isLoggedIn, setIsLoggedIn] = useState(true);
  const [phoneNumber, setPhoneNumber] = useState('0911234567');
  const [otpSent, setOtpSent] = useState(false);
  const [otpCode, setOtpCode] = useState('');
  const [authError, setAuthError] = useState('');

  // Booking selections
  const [pickup, setPickup] = useState<LocationPoint>(ADDIS_LOCATIONS[1]); // Meskel Square
  const [destination, setDestination] = useState<LocationPoint>(ADDIS_LOCATIONS[0]); // Bole Airport
  const [selectedTier, setSelectedTier] = useState<ServiceTier>('standard');
  const [paymentMethod, setPaymentMethod] = useState<'telebirr' | 'cbe_birr' | 'cash'>('telebirr');
  const [isSelectingLocation, setIsSelectingLocation] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const [chatInput, setChatInput] = useState('');
  const [rating, setRating] = useState(5);
  const [tip, setTip] = useState(0);

  // Quick distance calculation
  const dLat = (destination.lat - pickup.lat) * 111;
  const dLng = (destination.lng - pickup.lng) * 111 * Math.cos((pickup.lat * Math.PI) / 180);
  const estDistanceKm = Math.max(1.5, Math.round(Math.sqrt(dLat * dLat + dLng * dLng) * 10) / 10);
  const estTimeMin = Math.round(estDistanceKm * 2.8);

  // Price calculations
  const calculatePrice = (tier: ServiceTier) => {
    let base = 150;
    let rate = 40;
    if (tier === 'comfort') {
      base = 200;
      rate = 50;
    } else if (tier === 'minibus') {
      base = 120;
      rate = 30;
    } else if (tier === 'vip') {
      base = 350;
      rate = 80;
    }
    return Math.round(base + estDistanceKm * rate);
  };

  const handlePhoneSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!/^09\d{8}$/.test(phoneNumber.trim())) {
      setAuthError(t.invalidPhone);
      return;
    }
    setAuthError('');
    setOtpSent(true);
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    if (otpCode.trim() !== '1234') {
      setAuthError(t.demoOtpHint);
      return;
    }
    setAuthError('');
    setIsLoggedIn(true);
  };

  const handleHailRide = () => {
    createCustomerRide({
      pickup,
      destination,
      tier: selectedTier,
      paymentMethod,
      customerName: 'Alemayehu G.',
      customerPhone: phoneNumber,
    });
  };

  const handleFinishRating = () => {
    try {
      confetti({
        particleCount: 60,
        spread: 60,
        origin: { y: 0.7 },
      });
    } catch (e) {
      // ignore
    }
    rateAndFinishRide(rating, tip);
  };

  const handleSendChat = (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    sendChatMessage('customer', chatInput);
    setChatInput('');
  };

  return (
    <div className={`relative flex flex-col h-full bg-slate-900 text-slate-100 overflow-hidden ${inSplitView ? 'border border-slate-800 rounded-3xl shadow-2xl' : ''}`}>
      {/* Mobile Top App Bar */}
      <div className="flex items-center justify-between px-4 py-3 bg-slate-900/90 backdrop-blur-md border-b border-slate-800/80 z-20">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-amber-400 text-slate-950 font-black flex items-center justify-center text-sm shadow-md shadow-amber-400/20">
            A
          </div>
          <div>
            <div className="text-xs font-black tracking-wider text-amber-400 font-mono">
              ABDU RIDE
            </div>
            <div className="text-[10px] text-slate-400">
              {language === 'am' ? 'የደንበኛ መተግበሪያ' : 'Customer Passenger App'}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {isLoggedIn && (
            <button
              onClick={() => setIsLoggedIn(false)}
              title="Logout"
              className="p-1.5 text-slate-400 hover:text-slate-200 hover:bg-slate-800 rounded-lg transition-colors text-xs flex items-center gap-1"
            >
              <LogOut className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Auth Screen (if logged out) */}
      {!isLoggedIn ? (
        <div className="flex-1 flex flex-col justify-center px-6 py-8 bg-slate-950">
          <div className="text-center mb-6">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-amber-400 text-slate-950 text-3xl font-black mb-3 shadow-lg shadow-amber-400/20">
              🚖
            </div>
            <h2 className="text-xl font-bold text-white tracking-tight">
              {otpSent ? t.otpTitle : t.welcomeTitle}
            </h2>
            <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">
              {otpSent ? `${t.otpSubtitle} ${phoneNumber}` : t.welcomeSubtitle}
            </p>
          </div>

          {!otpSent ? (
            <form onSubmit={handlePhoneSubmit} className="space-y-4 max-w-xs mx-auto w-full">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">
                  {t.phoneLabel}
                </label>
                <div className="relative">
                  <Phone className="absolute left-3 top-3 w-4 h-4 text-amber-400" />
                  <input
                    type="tel"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    placeholder={t.phonePlaceholder}
                    maxLength={10}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-9 pr-3 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400 font-mono"
                  />
                </div>
              </div>

              {authError && <p className="text-xs text-rose-400">{authError}</p>}

              <button
                type="submit"
                className="w-full py-3 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold rounded-xl transition-all shadow-md shadow-amber-400/20 text-sm cursor-pointer"
              >
                {t.continueBtn}
              </button>

              <div className="text-center text-[11px] text-slate-500 pt-2">
                Demo phone: <code className="text-amber-400">0911234567</code>
              </div>
            </form>
          ) : (
            <form onSubmit={handleVerifyOtp} className="space-y-4 max-w-xs mx-auto w-full">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5 text-center">
                  4-Digit OTP Code
                </label>
                <input
                  type="text"
                  value={otpCode}
                  onChange={(e) => setOtpCode(e.target.value)}
                  placeholder="1234"
                  maxLength={4}
                  className="w-full text-center tracking-[1em] text-2xl font-mono font-bold bg-slate-900 border border-slate-700 rounded-xl py-2.5 text-white focus:outline-none focus:border-amber-400 focus:ring-1 focus:ring-amber-400"
                />
              </div>

              {authError && <p className="text-xs text-rose-400 text-center">{authError}</p>}

              <button
                type="submit"
                className="w-full py-3 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold rounded-xl transition-all shadow-md shadow-amber-400/20 text-sm cursor-pointer"
              >
                {t.verifyBtn}
              </button>

              <div className="flex justify-between items-center text-[11px] text-slate-400 pt-2">
                <button
                  type="button"
                  onClick={() => setOtpSent(false)}
                  className="hover:text-amber-400 transition-colors"
                >
                  Change Phone
                </button>
                <button
                  type="button"
                  onClick={() => setOtpCode('1234')}
                  className="text-amber-400 hover:underline"
                >
                  Auto-fill 1234
                </button>
              </div>
            </form>
          )}
        </div>
      ) : (
        /* Logged In Main Passenger View */
        <div className="relative flex-1 flex flex-col overflow-hidden">
          {/* Interactive Map Area */}
          <div className="relative flex-1 w-full bg-slate-950">
            <MapComponent
              pickupPoint={activeRide ? activeRide.pickup : pickup}
              dropoffPoint={activeRide ? activeRide.destination : destination}
              showAllDrivers={!activeRide}
              focusedDriverId={activeRide?.driverId}
            />

            {/* Quick Addis Preset Pills on Top when Idle */}
            {!activeRide && !isSelectingLocation && (
              <div className="absolute top-3 left-3 right-3 z-[400] flex items-center justify-between gap-2 pointer-events-auto">
                <button
                  onClick={() => setIsSelectingLocation(true)}
                  className="flex-1 bg-slate-900/95 hover:bg-slate-900 text-slate-200 border border-slate-700/80 rounded-2xl px-3.5 py-2.5 shadow-xl backdrop-blur-md flex items-center justify-between text-left transition-all"
                >
                  <div className="flex items-center gap-2.5 overflow-hidden">
                    <Search className="w-4 h-4 text-amber-400 shrink-0" />
                    <div className="truncate">
                      <div className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">
                        {language === 'am' ? 'መድረሻ ቦታ' : 'Destination'}
                      </div>
                      <div className="text-xs font-bold text-white truncate">
                        {language === 'am' ? destination.nameAm : destination.nameEn}
                      </div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400 shrink-0" />
                </button>
              </div>
            )}

            {/* Emergency SOS Banner if triggered */}
            {sosAlert?.active && (
              <div className="absolute top-16 left-3 right-3 z-[450] bg-rose-600/95 text-white p-3 rounded-2xl shadow-xl flex items-center gap-3 animate-pulse">
                <AlertTriangle className="w-5 h-5 shrink-0 text-amber-300" />
                <div className="flex-1 text-xs">
                  <div className="font-bold">{t.sosAlertActive}</div>
                  <div className="text-[11px] opacity-90">Police and dispatcher notified of live GPS position.</div>
                </div>
              </div>
            )}
          </div>

          {/* Location Selector Modal / Overlay */}
          {isSelectingLocation && !activeRide && (
            <div className="absolute inset-0 z-[500] bg-slate-950/95 backdrop-blur-md flex flex-col p-4 animate-in fade-in duration-200">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="font-bold text-sm text-white">
                  {language === 'am' ? 'የመነሻ እና መድረሻ መምረጫ' : 'Select Ride Route'}
                </div>
                <button
                  onClick={() => setIsSelectingLocation(false)}
                  className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-3 my-4">
                <div>
                  <div className="text-[11px] text-emerald-400 font-semibold mb-1 flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5" />
                    {t.pickupLocation}
                  </div>
                  <select
                    value={pickup.id}
                    onChange={(e) => {
                      const found = ADDIS_LOCATIONS.find((l) => l.id === e.target.value);
                      if (found) setPickup(found);
                    }}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-emerald-400"
                  >
                    {ADDIS_LOCATIONS.map((loc) => (
                      <option key={loc.id} value={loc.id}>
                        {language === 'am' ? loc.nameAm : loc.nameEn} ({loc.area})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <div className="text-[11px] text-amber-400 font-semibold mb-1 flex items-center gap-1">
                    <Navigation className="w-3.5 h-3.5" />
                    {t.dropoffLocation}
                  </div>
                  <select
                    value={destination.id}
                    onChange={(e) => {
                      const found = ADDIS_LOCATIONS.find((l) => l.id === e.target.value);
                      if (found) setDestination(found);
                    }}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                  >
                    {ADDIS_LOCATIONS.map((loc) => (
                      <option key={loc.id} value={loc.id}>
                        {language === 'am' ? loc.nameAm : loc.nameEn} ({loc.area})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="mt-auto">
                <button
                  onClick={() => setIsSelectingLocation(false)}
                  className="w-full py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold rounded-xl text-xs transition-colors"
                >
                  {language === 'am' ? 'ቦታዎችን አረጋግጥ' : 'Confirm Locations'}
                </button>
              </div>
            </div>
          )}

          {/* Bottom Sheet Controls */}
          <div className="bg-slate-900 border-t border-slate-800 p-4 shadow-2xl z-20">
            {/* 1. Idle Hailing Selection */}
            {!activeRide && (
              <div className="space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-200">{t.selectRideOptions}</span>
                  <span className="text-slate-400 font-mono text-[11px]">
                    {estDistanceKm} {t.km} · ~{estTimeMin} {t.min}
                  </span>
                </div>

                {/* Ride Vehicle Options */}
                <div className="grid grid-cols-2 gap-2">
                  {/* Standard Lada */}
                  <button
                    onClick={() => setSelectedTier('standard')}
                    className={`p-2.5 rounded-xl border text-left transition-all ${
                      selectedTier === 'standard'
                        ? 'border-amber-400 bg-amber-400/10 text-white'
                        : 'border-slate-800 bg-slate-950/40 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-lg">🚖</span>
                      <span className="text-xs font-bold text-amber-400 font-mono">
                        {calculatePrice('standard')} {t.birrSymbol}
                      </span>
                    </div>
                    <div className="text-xs font-bold truncate">
                      {language === 'am' ? 'አብዱ ስታንዳርድ (ላዳ)' : 'Abdu Standard (Lada)'}
                    </div>
                    <div className="text-[10px] text-slate-400 truncate">3-4 mins · Budget</div>
                  </button>

                  {/* Comfort Sedan */}
                  <button
                    onClick={() => setSelectedTier('comfort')}
                    className={`p-2.5 rounded-xl border text-left transition-all ${
                      selectedTier === 'comfort'
                        ? 'border-amber-400 bg-amber-400/10 text-white'
                        : 'border-slate-800 bg-slate-950/40 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-lg">🚗</span>
                      <span className="text-xs font-bold text-amber-400 font-mono">
                        {calculatePrice('comfort')} {t.birrSymbol}
                      </span>
                    </div>
                    <div className="text-xs font-bold truncate">
                      {language === 'am' ? 'አብዱ ኮምፎርት' : 'Abdu Comfort'}
                    </div>
                    <div className="text-[10px] text-slate-400 truncate">2 mins · AC Sedan</div>
                  </button>

                  {/* Minibus */}
                  <button
                    onClick={() => setSelectedTier('minibus')}
                    className={`p-2.5 rounded-xl border text-left transition-all ${
                      selectedTier === 'minibus'
                        ? 'border-amber-400 bg-amber-400/10 text-white'
                        : 'border-slate-800 bg-slate-950/40 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-lg">🚐</span>
                      <span className="text-xs font-bold text-amber-400 font-mono">
                        {calculatePrice('minibus')} {t.birrSymbol}
                      </span>
                    </div>
                    <div className="text-xs font-bold truncate">
                      {language === 'am' ? 'ጎ ሚኒባስ' : 'Go Minibus'}
                    </div>
                    <div className="text-[10px] text-slate-400 truncate">5 mins · Group/Luggage</div>
                  </button>

                  {/* VIP Executive */}
                  <button
                    onClick={() => setSelectedTier('vip')}
                    className={`p-2.5 rounded-xl border text-left transition-all ${
                      selectedTier === 'vip'
                        ? 'border-amber-400 bg-amber-400/10 text-white'
                        : 'border-slate-800 bg-slate-950/40 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-lg">🏎️</span>
                      <span className="text-xs font-bold text-amber-400 font-mono">
                        {calculatePrice('vip')} {t.birrSymbol}
                      </span>
                    </div>
                    <div className="text-xs font-bold truncate">
                      {language === 'am' ? 'አብዱ ቪአይፒ' : 'Abdu VIP Black'}
                    </div>
                    <div className="text-[10px] text-slate-400 truncate">Executive Chauffeur</div>
                  </button>
                </div>

                {/* Payment Selection */}
                <div className="flex items-center justify-between pt-1">
                  <div className="flex items-center gap-1.5 text-xs text-slate-300">
                    <span className="text-slate-400">{t.paymentMethod}:</span>
                    <button
                      onClick={() =>
                        setPaymentMethod((prev) =>
                          prev === 'telebirr' ? 'cbe_birr' : prev === 'cbe_birr' ? 'cash' : 'telebirr'
                        )
                      }
                      className="inline-flex items-center gap-1 px-2.5 py-1 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg text-amber-400 font-semibold transition-colors cursor-pointer"
                    >
                      <CreditCard className="w-3 h-3" />
                      {paymentMethod === 'telebirr' ? 'Telebirr (ቴሌብር)' : paymentMethod === 'cbe_birr' ? 'CBE Birr' : 'Cash'}
                    </button>
                  </div>
                </div>

                {/* Hail Taxi Button */}
                <button
                  onClick={handleHailRide}
                  className="w-full py-3 bg-amber-400 hover:bg-amber-300 active:scale-[0.99] text-slate-950 font-extrabold rounded-xl text-sm transition-all shadow-lg shadow-amber-400/25 flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Car className="w-4 h-4" />
                  <span>
                    {t.callTaxi} • {calculatePrice(selectedTier)} {t.birrSymbol}
                  </span>
                </button>
              </div>
            )}

            {/* 2. Active Ride Tracking (Searching / Arriving / In Progress) */}
            {activeRide && activeRide.status !== 'completed' && (
              <div className="space-y-3">
                {/* Searching State */}
                {activeRide.status === 'searching' && (
                  <div className="py-2 text-center space-y-2">
                    <div className="inline-block animate-spin w-8 h-8 border-3 border-amber-400 border-t-transparent rounded-full" />
                    <div className="text-sm font-bold text-white">{t.searchingDriver}</div>
                    <div className="text-xs text-slate-400">
                      Broadcasting to nearby drivers in {activeRide.pickup.area}...
                    </div>
                    <button
                      onClick={() => cancelRide('Passenger cancelled while searching')}
                      className="text-xs text-rose-400 hover:text-rose-300 underline pt-1 cursor-pointer"
                    >
                      {t.cancel}
                    </button>
                  </div>
                )}

                {/* Driver Assigned / Arriving / In Progress */}
                {activeRide.status !== 'searching' && (
                  <>
                    {/* Status Badge & PIN Notice */}
                    <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                      <div>
                        <div className="text-[10px] text-amber-400 uppercase tracking-wider font-bold">
                          {activeRide.status === 'arriving'
                            ? (language === 'am' ? 'ሹፌሩ ወደ እርስዎ እየመጣ ነው' : 'Driver En Route')
                            : activeRide.status === 'arrived'
                            ? (language === 'am' ? 'ሹፌሩ መነሻ ቦታ ደርሷል' : 'Driver Arrived at Pickup')
                            : (language === 'am' ? 'ጉዞው በመካሄድ ላይ' : 'Trip In Progress')}
                        </div>
                        <div className="text-xs font-semibold text-white">
                          {activeRide.status === 'in_progress' ? `ETA ~${activeRide.durationMinutes} min` : 'ETA ~2-3 min'}
                        </div>
                      </div>

                      {/* Security PIN Capsule */}
                      <div className="bg-amber-400/15 border border-amber-400/30 rounded-xl px-3 py-1 text-right">
                        <div className="text-[9px] text-amber-300 uppercase font-semibold">Safety PIN</div>
                        <div className="text-base font-black text-amber-400 font-mono tracking-widest leading-none">
                          {activeRide.pin}
                        </div>
                      </div>
                    </div>

                    {/* Driver Card */}
                    <div className="flex items-center justify-between bg-slate-950/60 p-2.5 rounded-xl border border-slate-800">
                      <div className="flex items-center gap-3">
                        <img
                          src={activeRide.driverAvatar || 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80'}
                          alt="Driver"
                          className="w-10 h-10 rounded-xl object-cover border border-amber-400/40"
                        />
                        <div>
                          <div className="text-xs font-bold text-white flex items-center gap-1.5">
                            {activeRide.driverName}
                            <span className="text-[10px] text-amber-400 font-normal">★ {activeRide.driverRating}</span>
                          </div>
                          <div className="text-[10px] text-slate-400">{activeRide.driverVehicle}</div>
                          <div className="text-[10px] text-amber-300 font-mono font-semibold">{activeRide.driverPlate}</div>
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => setChatOpen(true)}
                          className="p-2 bg-slate-800 hover:bg-slate-700 text-amber-400 rounded-xl transition-colors relative"
                          title="Chat with driver"
                        >
                          <MessageSquare className="w-4 h-4" />
                          {chatMessages.length > 0 && (
                            <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-amber-400 rounded-full" />
                          )}
                        </button>

                        <a
                          href={`tel:${activeRide.driverPhone}`}
                          className="p-2 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 rounded-xl transition-colors border border-emerald-500/30"
                          title="Call driver"
                        >
                          <Phone className="w-4 h-4" />
                        </a>
                      </div>
                    </div>

                    {/* Route Details */}
                    <div className="text-[11px] text-slate-400 flex items-center justify-between px-1">
                      <div className="truncate max-w-[190px]">
                        <span className="text-slate-500">To:</span> {activeRide.destination.nameEn}
                      </div>
                      <div className="font-mono font-semibold text-slate-200">
                        {activeRide.fareEtb} {t.birrSymbol} ({activeRide.paymentMethod.toUpperCase()})
                      </div>
                    </div>

                    {/* Action buttons: SOS & Cancel */}
                    <div className="flex items-center gap-2 pt-1">
                      <button
                        onClick={triggerSOS}
                        className="flex-1 py-2 px-3 bg-rose-950/40 hover:bg-rose-900/60 border border-rose-800/60 text-rose-300 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <ShieldAlert className="w-3.5 h-3.5 text-rose-400" />
                        <span>{t.sos}</span>
                      </button>

                      <button
                        onClick={() => cancelRide('Passenger requested cancellation')}
                        className="py-2 px-3 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium rounded-xl transition-colors cursor-pointer"
                      >
                        {t.cancel}
                      </button>
                    </div>
                  </>
                )}
              </div>
            )}

            {/* 3. Trip Completed / Payment & Rating View */}
            {activeRide && activeRide.status === 'completed' && (
              <div className="space-y-3 animate-in fade-in">
                <div className="text-center pb-2 border-b border-slate-800">
                  <div className="inline-flex p-2 bg-emerald-500/20 text-emerald-400 rounded-full mb-1">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <h3 className="text-sm font-bold text-white">{t.tripCompleted}</h3>
                  <div className="text-2xl font-black text-amber-400 font-mono mt-1">
                    {activeRide.fareEtb} {t.birrSymbol}
                  </div>
                  <div className="text-[11px] text-slate-400">
                    Paid via {activeRide.paymentMethod.toUpperCase()} · Telebirr receipt #TB{Math.floor(100000 + Math.random() * 900000)}
                  </div>
                </div>

                {/* Rating Stars */}
                <div>
                  <div className="text-xs text-center text-slate-300 mb-1.5 font-medium">
                    {t.rateDriver} {activeRide.driverName}
                  </div>
                  <div className="flex justify-center gap-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        onClick={() => setRating(star)}
                        className={`p-1.5 transition-transform hover:scale-110 cursor-pointer ${
                          rating >= star ? 'text-amber-400' : 'text-slate-600'
                        }`}
                      >
                        <Star className="w-6 h-6 fill-current" />
                      </button>
                    ))}
                  </div>
                </div>

                {/* Driver Tip */}
                <div>
                  <div className="text-[11px] text-slate-400 text-center mb-1.5">{t.tipDriver}</div>
                  <div className="flex justify-center gap-2">
                    {[0, 20, 50, 100].map((amount) => (
                      <button
                        key={amount}
                        onClick={() => setTip(amount)}
                        className={`px-3 py-1 rounded-lg text-xs font-semibold font-mono transition-all ${
                          tip === amount
                            ? 'bg-amber-400 text-slate-950 shadow-md'
                            : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                        }`}
                      >
                        {amount === 0 ? 'No tip' : `+${amount} ETB`}
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  onClick={handleFinishRating}
                  className="w-full py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold rounded-xl text-xs transition-colors shadow-md shadow-amber-400/20 cursor-pointer"
                >
                  {t.submitReview}
                </button>
              </div>
            )}
          </div>

          {/* In-App Chat Slide-over Drawer */}
          {chatOpen && (
            <div className="absolute inset-0 z-[600] bg-slate-950/95 backdrop-blur-md flex flex-col p-4 animate-in fade-in duration-200">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
                  <div className="text-xs font-bold text-white">
                    Chat with {activeRide?.driverName || 'Driver'}
                  </div>
                </div>
                <button
                  onClick={() => setChatOpen(false)}
                  className="p-1 rounded-lg text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Message Feed */}
              <div className="flex-1 overflow-y-auto space-y-2 py-3">
                {chatMessages.length === 0 ? (
                  <div className="text-center text-xs text-slate-500 py-8">
                    Send a message to your driver (e.g. pickup details)
                  </div>
                ) : (
                  chatMessages.map((msg) => (
                    <div
                      key={msg.id}
                      className={`flex flex-col ${
                        msg.sender === 'customer'
                          ? 'items-end'
                          : msg.sender === 'driver'
                          ? 'items-start'
                          : 'items-center'
                      }`}
                    >
                      {msg.sender === 'system' ? (
                        <div className="text-[10px] text-amber-400/90 bg-amber-400/10 px-2 py-1 rounded-md my-1 text-center font-mono">
                          {msg.text}
                        </div>
                      ) : (
                        <div
                          className={`max-w-[78%] px-3 py-2 rounded-2xl text-xs leading-relaxed ${
                            msg.sender === 'customer'
                              ? 'bg-amber-400 text-slate-950 font-medium rounded-br-none'
                              : 'bg-slate-800 text-white rounded-bl-none'
                          }`}
                        >
                          {msg.text}
                          <div
                            className={`text-[9px] mt-0.5 text-right opacity-70 ${
                              msg.sender === 'customer' ? 'text-slate-800' : 'text-slate-400'
                            }`}
                          >
                            {msg.timestamp}
                          </div>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>

              {/* Chat Input */}
              <form onSubmit={handleSendChat} className="flex gap-2 pt-2 border-t border-slate-800">
                <input
                  type="text"
                  value={chatInput}
                  onChange={(e) => setChatInput(e.target.value)}
                  placeholder="Type a message..."
                  className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                />
                <button
                  type="submit"
                  className="p-2 bg-amber-400 hover:bg-amber-300 text-slate-950 rounded-xl transition-colors cursor-pointer"
                >
                  <Send className="w-4 h-4" />
                </button>
              </form>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
