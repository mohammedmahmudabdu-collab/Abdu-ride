import React from 'react';
import {
  Activity,
  Radio,
  Car,
  Users,
  DollarSign,
  TrendingUp,
  AlertTriangle,
  Play,
  RotateCcw,
  CheckCircle2,
  Clock,
  MapPin,
  ShieldAlert,
  Sliders,
  Terminal,
} from 'lucide-react';
import { useRideControl } from '../context/RideControlContext';
import { translations, ADDIS_LOCATIONS } from '../utils/i18n';
import { MapComponent } from './MapComponent';

export const DispatchControlCenter: React.FC = () => {
  const {
    language,
    drivers,
    activeRide,
    allRides,
    logs,
    surgeMultiplier,
    setSurgeMultiplier,
    sosAlert,
    dismissSOS,
    quickDemoHail,
    driverAcceptRide,
    driverMarkArrived,
    driverStartTrip,
    driverCompleteTrip,
    resetAll,
  } = useRideControl();

  const t = translations[language];

  const onlineDriversCount = drivers.filter((d) => d.isOnline).length;
  const activeTripsCount = (activeRide && activeRide.status !== 'completed' && activeRide.status !== 'idle') ? 1 : 0;
  const totalCompletedTrips = allRides.length;
  const platformRevenueToday = allRides.reduce((acc, r) => acc + r.fareEtb, 0) + (activeRide?.fareEtb || 0) * 0.15;

  return (
    <div className="flex-1 flex flex-col h-full bg-slate-950 text-slate-100 overflow-hidden">
      {/* Top Operations Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 px-6 py-3.5 bg-slate-900 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-amber-400 text-slate-950 font-black flex items-center justify-center text-base shadow-md shadow-amber-400/20">
            📡
          </div>
          <div>
            <div className="text-sm font-black text-white flex items-center gap-2">
              <span>{t.controlCenterTitle}</span>
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                LIVE
              </span>
            </div>
            <div className="text-xs text-slate-400 font-mono">
              Addis Ababa Fleet Hub · Sub-city Dispatch Grid
            </div>
          </div>
        </div>

        {/* Quick Simulator Controls Bar */}
        <div className="flex items-center gap-2">
          <button
            onClick={quickDemoHail}
            className="px-3 py-1.5 bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-bold rounded-xl transition-all shadow-md shadow-amber-400/20 flex items-center gap-1.5 cursor-pointer"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>{t.triggerDemoRide}</span>
          </button>

          {activeRide?.status === 'searching' && (
            <button
              onClick={() => driverAcceptRide()}
              className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold rounded-xl transition-colors cursor-pointer"
            >
              Simulate Driver Accept
            </button>
          )}

          {activeRide?.status === 'arriving' && (
            <button
              onClick={driverMarkArrived}
              className="px-3 py-1.5 bg-sky-500 hover:bg-sky-400 text-slate-950 text-xs font-bold rounded-xl transition-colors cursor-pointer"
            >
              Simulate Driver Arrived
            </button>
          )}

          {activeRide?.status === 'arrived' && (
            <button
              onClick={() => driverStartTrip(activeRide.pin)}
              className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold rounded-xl transition-colors cursor-pointer"
            >
              Verify PIN & Start Trip
            </button>
          )}

          {activeRide?.status === 'in_progress' && (
            <button
              onClick={driverCompleteTrip}
              className="px-3 py-1.5 bg-purple-500 hover:bg-purple-400 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
            >
              Simulate Trip Complete
            </button>
          )}

          <button
            onClick={resetAll}
            title={t.resetSimulation}
            className="p-1.5 text-slate-400 hover:text-rose-400 hover:bg-slate-800 rounded-xl transition-colors cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Emergency SOS Banner (If Active) */}
      {sosAlert?.active && (
        <div className="bg-rose-950 border-y border-rose-800 px-6 py-3 flex items-center justify-between text-rose-200 animate-pulse">
          <div className="flex items-center gap-3">
            <ShieldAlert className="w-6 h-6 text-rose-400 shrink-0" />
            <div>
              <div className="text-xs font-black text-white uppercase tracking-wider">
                {t.sosAlertActive}
              </div>
              <div className="text-xs text-rose-300">
                {sosAlert.message} · Timestamp: {sosAlert.timestamp}
              </div>
            </div>
          </div>
          <button
            onClick={dismissSOS}
            className="px-3 py-1.5 bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold rounded-xl transition-colors cursor-pointer"
          >
            Dismiss SOS Alert
          </button>
        </div>
      )}

      {/* Operations Telemetry KPI Metrics Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 px-6 py-4 bg-slate-900/50 border-b border-slate-800/80">
        <div className="bg-slate-900 p-3.5 rounded-2xl border border-slate-800">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>{t.activeVehicles}</span>
            <Car className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-xl font-black text-white font-mono">
            {onlineDriversCount} <span className="text-xs text-slate-500">/ {drivers.length} Units</span>
          </div>
        </div>

        <div className="bg-slate-900 p-3.5 rounded-2xl border border-slate-800">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>{t.ongoingTrips}</span>
            <Radio className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-xl font-black text-amber-400 font-mono">
            {activeTripsCount} <span className="text-xs text-slate-500">In Motion</span>
          </div>
        </div>

        <div className="bg-slate-900 p-3.5 rounded-2xl border border-slate-800">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>{t.totalRevenue}</span>
            <DollarSign className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-xl font-black text-emerald-400 font-mono">
            {Math.round(platformRevenueToday)} <span className="text-xs font-sans text-slate-400">{t.birrSymbol}</span>
          </div>
        </div>

        {/* Dynamic Surge Pricing Controller */}
        <div className="bg-slate-900 p-3 rounded-2xl border border-slate-800">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>{t.surgeMultiplier}</span>
            <span className="text-amber-400 font-mono font-bold">{surgeMultiplier.toFixed(1)}x</span>
          </div>
          <input
            type="range"
            min="1.0"
            max="2.5"
            step="0.1"
            value={surgeMultiplier}
            onChange={(e) => setSurgeMultiplier(parseFloat(e.target.value))}
            className="w-full accent-amber-400 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
          />
          <div className="flex justify-between text-[10px] text-slate-500 mt-1">
            <span>1.0x Normal</span>
            <span>2.5x Peak Rush</span>
          </div>
        </div>
      </div>

      {/* Main Split Layout: Left Map / Right Operational Logs & Fleet Details */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
        {/* Left: Expansive Live Fleet Map */}
        <div className="flex-1 relative bg-slate-950 border-r border-slate-800 min-h-[320px]">
          <MapComponent
            height="100%"
            showAllDrivers={true}
            pickupPoint={activeRide?.pickup}
            dropoffPoint={activeRide?.destination}
          />

          {/* Active Ride HUD Overlay on Map */}
          {activeRide && (
            <div className="absolute top-4 left-4 z-[400] bg-slate-900/95 backdrop-blur-md border border-slate-700/80 rounded-2xl p-3.5 shadow-2xl max-w-sm">
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="font-bold text-amber-400 uppercase tracking-wider">
                  Active Dispatch: {activeRide.id}
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-400/20 text-amber-300 uppercase">
                  {activeRide.status}
                </span>
              </div>
              <div className="text-xs space-y-1">
                <div>
                  <span className="text-slate-400">Customer:</span> {activeRide.customerName} ({activeRide.customerPhone})
                </div>
                <div>
                  <span className="text-slate-400">From:</span> {activeRide.pickup.nameEn}
                </div>
                <div>
                  <span className="text-slate-400">To:</span> {activeRide.destination.nameEn}
                </div>
                <div className="flex justify-between pt-1 font-mono text-slate-200">
                  <span>Fare: {activeRide.fareEtb} ETB</span>
                  <span>Safety PIN: <strong className="text-amber-400">{activeRide.pin}</strong></span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Right Sidebar: Fleet Directory & Live Terminal Logs */}
        <div className="w-full lg:w-96 flex flex-col bg-slate-900/60 overflow-hidden">
          {/* Active Drivers List */}
          <div className="p-4 border-b border-slate-800 flex-1 overflow-y-auto">
            <div className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3 flex items-center justify-between">
              <span>{t.driverDirectory}</span>
              <span className="text-slate-500 font-mono text-[11px]">{drivers.length} Units</span>
            </div>

            <div className="space-y-2.5">
              {drivers.map((driver) => (
                <div
                  key={driver.id}
                  className="bg-slate-900 p-3 rounded-xl border border-slate-800 hover:border-slate-700 transition-colors"
                >
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-2">
                      <div className={`w-2 h-2 rounded-full ${driver.isOnline ? 'bg-emerald-400' : 'bg-slate-600'}`} />
                      <span className="text-xs font-bold text-white">{driver.name}</span>
                    </div>
                    <span className="text-xs font-mono font-bold text-amber-400">★ {driver.rating}</span>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span className="font-mono">{driver.vehicle.plate}</span>
                    <span>{driver.vehicle.model}</span>
                  </div>

                  <div className="flex items-center justify-between text-[10px] text-slate-500 mt-1 pt-1 border-t border-slate-800/60 font-mono">
                    <span>Status: {driver.status.toUpperCase()}</span>
                    <span className="text-emerald-400 font-semibold">{driver.todayEarnings} ETB Today</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Live Dispatch Terminal Logs */}
          <div className="p-4 border-t border-slate-800 bg-slate-950 flex flex-col h-56">
            <div className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Terminal className="w-3.5 h-3.5 text-amber-400" />
              <span>{t.recentLogs}</span>
            </div>

            <div className="flex-1 overflow-y-auto space-y-1.5 font-mono text-[11px] pr-1">
              {logs.map((log) => (
                <div
                  key={log.id}
                  className={`leading-relaxed ${
                    log.type === 'emergency'
                      ? 'text-rose-400 font-bold'
                      : log.type === 'driver'
                      ? 'text-sky-300'
                      : log.type === 'ride'
                      ? 'text-amber-300'
                      : 'text-slate-400'
                  }`}
                >
                  <span className="text-slate-600 select-none">[{log.time}]</span> {log.message}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
