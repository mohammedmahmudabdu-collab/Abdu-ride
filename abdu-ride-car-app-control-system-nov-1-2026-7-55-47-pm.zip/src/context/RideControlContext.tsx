import React, { createContext, useContext, useState, useEffect, useRef } from 'react';
import {
  RideRequest,
  DriverState,
  ChatMessage,
  AppViewMode,
  Language,
  LocationPoint,
  ServiceTier,
} from '../types/ride';
import { soundEffects } from '../utils/audio';
import { ADDIS_LOCATIONS } from '../utils/i18n';

interface LogItem {
  id: string;
  time: string;
  type: 'dispatch' | 'ride' | 'driver' | 'emergency';
  message: string;
}

interface RideControlContextType {
  viewMode: AppViewMode;
  setViewMode: (v: AppViewMode) => void;
  language: Language;
  setLanguage: (l: Language) => void;
  soundEnabled: boolean;
  setSoundEnabled: (v: boolean) => void;
  activeRide: RideRequest | null;
  allRides: RideRequest[];
  drivers: DriverState[];
  currentDriver: DriverState;
  surgeMultiplier: number;
  setSurgeMultiplier: (s: number) => void;
  logs: LogItem[];
  chatMessages: ChatMessage[];
  sosAlert: { active: boolean; message: string; timestamp: string } | null;

  // Actions
  createCustomerRide: (params: {
    pickup: LocationPoint;
    destination: LocationPoint;
    tier: ServiceTier;
    paymentMethod: 'telebirr' | 'cbe_birr' | 'cash';
    customerName: string;
    customerPhone: string;
  }) => void;
  cancelRide: (reason?: string) => void;
  driverAcceptRide: (driverId?: string) => void;
  driverDeclineRide: (driverId?: string) => void;
  driverMarkArrived: () => void;
  driverStartTrip: (pin: string) => boolean;
  driverCompleteTrip: () => void;
  rateAndFinishRide: (rating: number, tip: number) => void;
  toggleDriverOnline: (driverId: string) => void;
  withdrawTelebirr: (driverId: string, amount: number) => boolean;
  sendChatMessage: (sender: 'customer' | 'driver', text: string) => void;
  triggerSOS: () => void;
  dismissSOS: () => void;
  resetAll: () => void;
  quickDemoHail: () => void;
}

const INITIAL_DRIVERS: DriverState[] = [
  {
    id: 'driver_1',
    name: 'Dawit Bekele (ዳዊት)',
    nameAm: 'ዳዊት በቀለ',
    phone: '0911 23 45 67',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
    isOnline: true,
    status: 'idle',
    vehicle: {
      make: 'Toyota',
      model: 'Corolla Blue/White Lada Taxi',
      plate: 'AA 2-B12948',
      color: 'Blue & White',
      year: '2008',
      tier: 'standard',
    },
    location: {
      lat: 9.0125,
      lng: 38.7580,
      heading: 45,
    },
    todayEarnings: 1850,
    totalTrips: 1420,
    acceptanceRate: 98,
    rating: 4.9,
    walletBalance: 4200,
  },
  {
    id: 'driver_2',
    name: 'Abebe Tadesse (አበበ)',
    nameAm: 'አበበ ታደሰ',
    phone: '0922 88 19 32',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
    isOnline: true,
    status: 'idle',
    vehicle: {
      make: 'Toyota',
      model: 'Vitz Sedan Clean',
      plate: 'AA 3-A44012',
      color: 'Silver Metallic',
      year: '2016',
      tier: 'comfort',
    },
    location: {
      lat: 8.9850,
      lng: 38.7890,
      heading: 120,
    },
    todayEarnings: 2400,
    totalTrips: 890,
    acceptanceRate: 95,
    rating: 4.85,
    walletBalance: 3100,
  },
  {
    id: 'driver_3',
    name: 'Yared Hailu (ያሬድ)',
    nameAm: 'ያሬድ ኃይሉ',
    phone: '0944 55 11 02',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80',
    isOnline: true,
    status: 'idle',
    vehicle: {
      make: 'Toyota',
      model: 'Hiace 12-Seat Minibus',
      plate: 'AA 1-C99214',
      color: 'White / Blue Stripe',
      year: '2014',
      tier: 'minibus',
    },
    location: {
      lat: 9.0220,
      lng: 38.8040,
      heading: 270,
    },
    todayEarnings: 3100,
    totalTrips: 2150,
    acceptanceRate: 92,
    rating: 4.78,
    walletBalance: 5600,
  },
  {
    id: 'driver_4',
    name: 'Michael Solomon (ሚካኤል)',
    nameAm: 'ሚካኤል ሰለሞን',
    phone: '0930 14 77 99',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=150&q=80',
    isOnline: true,
    status: 'idle',
    vehicle: {
      make: 'Hyundai',
      model: 'Sonata Executive Black',
      plate: 'AA 2-D77103',
      color: 'Obsidian Black',
      year: '2022',
      tier: 'vip',
    },
    location: {
      lat: 9.0200,
      lng: 38.7710,
      heading: 90,
    },
    todayEarnings: 4200,
    totalTrips: 640,
    acceptanceRate: 100,
    rating: 5.0,
    walletBalance: 8900,
  },
];

const RideControlContext = createContext<RideControlContextType | undefined>(undefined);

export const RideControlProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [viewMode, setViewMode] = useState<AppViewMode>('split');
  const [language, setLanguage] = useState<Language>('am');
  const [soundEnabled, setSoundEnabledState] = useState<boolean>(true);
  const [surgeMultiplier, setSurgeMultiplier] = useState<number>(1.1);
  const [drivers, setDrivers] = useState<DriverState[]>(INITIAL_DRIVERS);
  const [activeDriverId] = useState<string>('driver_1');
  const [activeRide, setActiveRide] = useState<RideRequest | null>(null);
  const [allRides, setAllRides] = useState<RideRequest[]>([]);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [sosAlert, setSosAlert] = useState<{ active: boolean; message: string; timestamp: string } | null>(null);
  const [logs, setLogs] = useState<LogItem[]>([
    {
      id: 'log_0',
      time: new Date().toLocaleTimeString(),
      type: 'dispatch',
      message: 'ABDU RIDE Central Dispatch Server initialized. Fleet GPS tracking active.',
    },
    {
      id: 'log_1',
      time: new Date().toLocaleTimeString(),
      type: 'driver',
      message: '4 Driver partners currently online across Addis Ababa (Bole, Meskel Sq, Kazanchis, Megenagna).',
    },
  ]);

  const soundRef = useRef(soundEnabled);
  useEffect(() => {
    soundRef.current = soundEnabled;
    soundEffects.enabled = soundEnabled;
  }, [soundEnabled]);

  const setSoundEnabled = (val: boolean) => {
    setSoundEnabledState(val);
    soundEffects.enabled = val;
  };

  const addLog = (message: string, type: 'dispatch' | 'ride' | 'driver' | 'emergency' = 'dispatch') => {
    const item: LogItem = {
      id: 'log_' + Date.now() + Math.random().toString(36).substring(2, 5),
      time: new Date().toLocaleTimeString(),
      type,
      message,
    };
    setLogs((prev) => [item, ...prev.slice(0, 50)]);
  };

  const currentDriver = drivers.find((d) => d.id === activeDriverId) || drivers[0];

  // Create Customer Ride Request
  const createCustomerRide = (params: {
    pickup: LocationPoint;
    destination: LocationPoint;
    tier: ServiceTier;
    paymentMethod: 'telebirr' | 'cbe_birr' | 'cash';
    customerName: string;
    customerPhone: string;
  }) => {
    // Calculate distance approx
    const dLat = (params.destination.lat - params.pickup.lat) * 111;
    const dLng = (params.destination.lng - params.pickup.lng) * 111 * Math.cos((params.pickup.lat * Math.PI) / 180);
    const distKm = Math.max(1.8, Math.round(Math.sqrt(dLat * dLat + dLng * dLng) * 10) / 10);
    const estMinutes = Math.max(5, Math.round(distKm * 2.8));

    // Base fare rates
    let base = 150;
    let perKm = 40;
    if (params.tier === 'comfort') {
      base = 200;
      perKm = 50;
    } else if (params.tier === 'minibus') {
      base = 120;
      perKm = 30;
    } else if (params.tier === 'vip') {
      base = 350;
      perKm = 80;
    }

    const rawFare = Math.round((base + distKm * perKm) * surgeMultiplier);
    // 4-digit security PIN
    const generatedPin = Math.floor(1000 + Math.random() * 9000).toString();

    const newRide: RideRequest = {
      id: 'ABDU-' + Math.floor(100000 + Math.random() * 900000),
      customerId: 'cust_01',
      customerName: params.customerName || 'Alemayehu G.',
      customerPhone: params.customerPhone || '0911223344',
      pickup: params.pickup,
      destination: params.destination,
      tier: params.tier,
      fareEtb: rawFare,
      distanceKm: distKm,
      durationMinutes: estMinutes,
      pin: generatedPin,
      status: 'searching',
      paymentMethod: params.paymentMethod,
      paymentStatus: 'pending',
      createdAt: Date.now(),
    };

    setActiveRide(newRide);
    addLog(`Ride requested: ${newRide.id} | From: ${newRide.pickup.nameEn} to ${newRide.destination.nameEn} | ${rawFare} ETB`, 'ride');
    soundEffects.playRequestAlert();

    // Auto broadcast to Driver 1 (or matching tier driver)
    setTimeout(() => {
      setDrivers((prev) =>
        prev.map((d) => {
          if (d.id === activeDriverId) {
            return {
              ...d,
              currentRideId: newRide.id,
            };
          }
          return d;
        })
      );
      soundEffects.playRequestAlert();
      addLog(`Dispatched request ${newRide.id} to Driver ${currentDriver.name}`, 'dispatch');
    }, 1200);
  };

  // Driver accepts ride
  const driverAcceptRide = (driverId = activeDriverId) => {
    if (!activeRide) return;
    const assigned = drivers.find((d) => d.id === driverId) || currentDriver;

    const updatedRide: RideRequest = {
      ...activeRide,
      status: 'arriving',
      driverId: assigned.id,
      driverName: assigned.name,
      driverPhone: assigned.phone,
      driverPlate: assigned.vehicle.plate,
      driverVehicle: `${assigned.vehicle.make} ${assigned.vehicle.model}`,
      driverRating: assigned.rating,
      driverAvatar: assigned.avatar,
      acceptedAt: Date.now(),
    };

    setActiveRide(updatedRide);
    setDrivers((prev) =>
      prev.map((d) => (d.id === assigned.id ? { ...d, status: 'heading_pickup', currentRideId: updatedRide.id } : d))
    );

    soundEffects.playAcceptChime();
    addLog(`Driver ${assigned.name} accepted ride ${activeRide.id}! Route started to pickup.`, 'driver');

    // System message
    setChatMessages([
      {
        id: 'msg_' + Date.now(),
        rideId: activeRide.id,
        sender: 'system',
        text: `Driver ${assigned.name} is on the way! Safety PIN is ${activeRide.pin}.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
  };

  // Driver declines ride
  const driverDeclineRide = (driverId = activeDriverId) => {
    if (!activeRide) return;
    soundEffects.playClick();
    addLog(`Driver declined ride ${activeRide.id}. Re-routing to next fleet driver...`, 'dispatch');
    // find next driver
    const otherDriver = drivers.find((d) => d.id !== driverId && d.isOnline);
    if (otherDriver) {
      setTimeout(() => {
        driverAcceptRide(otherDriver.id);
      }, 1500);
    }
  };

  // Driver marks arrived
  const driverMarkArrived = () => {
    if (!activeRide) return;
    setActiveRide((prev) => (prev ? { ...prev, status: 'arrived' } : null));
    setDrivers((prev) =>
      prev.map((d) => (d.id === activeRide.driverId ? { ...d, status: 'at_pickup' } : d))
    );
    soundEffects.playArrivedBell();
    addLog(`Driver arrived at passenger pickup: ${activeRide.pickup.nameEn}`, 'driver');
  };

  // Driver starts trip with customer PIN
  const driverStartTrip = (pinInput: string): boolean => {
    if (!activeRide) return false;
    if (pinInput.trim() !== activeRide.pin.trim()) {
      soundEffects.playClick();
      addLog(`PIN verification failed for ${activeRide.id} (Entered: ${pinInput}, Required: ${activeRide.pin})`, 'emergency');
      return false;
    }

    setActiveRide((prev) => (prev ? { ...prev, status: 'in_progress', startedAt: Date.now() } : null));
    setDrivers((prev) =>
      prev.map((d) => (d.id === activeRide.driverId ? { ...d, status: 'on_trip' } : d))
    );
    soundEffects.playAcceptChime();
    addLog(`Trip started successfully for ${activeRide.id}! Destination: ${activeRide.destination.nameEn}`, 'ride');
    return true;
  };

  // Driver completes trip
  const driverCompleteTrip = () => {
    if (!activeRide) return;
    const completedRide: RideRequest = {
      ...activeRide,
      status: 'completed',
      completedAt: Date.now(),
    };

    setActiveRide(completedRide);
    setAllRides((prev) => [completedRide, ...prev]);

    // Update driver wallet & stats
    const driverFareShare = Math.round(activeRide.fareEtb * 0.85); // 85% driver, 15% platform
    setDrivers((prev) =>
      prev.map((d) => {
        if (d.id === activeRide.driverId) {
          return {
            ...d,
            status: 'idle',
            currentRideId: undefined,
            todayEarnings: d.todayEarnings + driverFareShare,
            totalTrips: d.totalTrips + 1,
            walletBalance: d.walletBalance + driverFareShare,
          };
        }
        return d;
      })
    );

    soundEffects.playCompletedCash();
    addLog(`Trip ${activeRide.id} COMPLETED! Collected: ${activeRide.fareEtb} ETB. Driver payout share: ${driverFareShare} ETB.`, 'ride');
  };

  // Customer rates and completes payment
  const rateAndFinishRide = (rating: number, tip: number) => {
    if (!activeRide) return;
    soundEffects.playCompletedCash();
    addLog(`Customer submitted rating: ${rating} Stars | Tip: ${tip} ETB. Ride finalized.`, 'ride');

    // Update driver rating
    if (activeRide.driverId && tip > 0) {
      setDrivers((prev) =>
        prev.map((d) => (d.id === activeRide.driverId ? { ...d, walletBalance: d.walletBalance + tip } : d))
      );
    }

    setActiveRide(null);
    setChatMessages([]);
  };

  // Cancel ride
  const cancelRide = (reason = 'Customer cancelled') => {
    if (!activeRide) return;
    soundEffects.playClick();
    addLog(`Ride ${activeRide.id} was cancelled. Reason: ${reason}`, 'emergency');

    if (activeRide.driverId) {
      setDrivers((prev) =>
        prev.map((d) => (d.id === activeRide.driverId ? { ...d, status: 'idle', currentRideId: undefined } : d))
      );
    }
    setActiveRide(null);
    setChatMessages([]);
  };

  // Driver toggle online/offline
  const toggleDriverOnline = (driverId: string) => {
    soundEffects.playClick();
    setDrivers((prev) =>
      prev.map((d) => {
        if (d.id === driverId) {
          const nextOnline = !d.isOnline;
          addLog(`Driver ${d.name} turned ${nextOnline ? 'ONLINE' : 'OFFLINE'}`, 'driver');
          return {
            ...d,
            isOnline: nextOnline,
            status: nextOnline ? 'idle' : 'offline',
          };
        }
        return d;
      })
    );
  };

  // Withdraw wallet to Telebirr
  const withdrawTelebirr = (driverId: string, amount: number): boolean => {
    const driver = drivers.find((d) => d.id === driverId);
    if (!driver || driver.walletBalance < amount) return false;

    soundEffects.playCompletedCash();
    setDrivers((prev) =>
      prev.map((d) => (d.id === driverId ? { ...d, walletBalance: d.walletBalance - amount } : d))
    );
    addLog(`Telebirr instant payout processed: ${amount} ETB to Driver ${driver.name} (Phone: ${driver.phone})`, 'dispatch');
    return true;
  };

  // In-app chat
  const sendChatMessage = (sender: 'customer' | 'driver', text: string) => {
    if (!text.trim() || !activeRide) return;
    const msg: ChatMessage = {
      id: 'msg_' + Date.now(),
      rideId: activeRide.id,
      sender,
      text: text.trim(),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setChatMessages((prev) => [...prev, msg]);
    soundEffects.playClick();

    // Auto simulated reply if customer sent message
    if (sender === 'customer') {
      setTimeout(() => {
        const replies = [
          'እሺ ደርሻለሁ፣ ቢጫ መብራቴ በርቷል።',
          'መንገዱ ትንሽ መጨናነቅ አለው፣ 2 ደቂቃ ውስጥ እደርሳለሁ።',
          'OK! I am parked right next to the entrance gate in the blue taxi.',
          'አየሁዎት፣ አሁን መኪናውን እያቆምኩ ነው።',
        ];
        const randomReply = replies[Math.floor(Math.random() * replies.length)];
        const replyMsg: ChatMessage = {
          id: 'msg_' + (Date.now() + 1),
          rideId: activeRide.id,
          sender: 'driver',
          text: randomReply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        setChatMessages((p) => [...p, replyMsg]);
        soundEffects.playClick();
      }, 1500);
    }
  };

  // SOS Emergency
  const triggerSOS = () => {
    soundEffects.playRequestAlert();
    const alertData = {
      active: true,
      message: `POLICE & DISPATCH ALERT: Customer triggered SOS emergency button! Live coordinates tracked.`,
      timestamp: new Date().toLocaleTimeString(),
    };
    setSosAlert(alertData);
    addLog(`CRITICAL SOS: Emergency triggered on Ride ${activeRide?.id || 'Active Unit'}! High priority dispatch alert!`, 'emergency');
  };

  const dismissSOS = () => {
    setSosAlert(null);
    addLog('Emergency SOS situation cleared by dispatch operator.', 'dispatch');
  };

  // Reset all
  const resetAll = () => {
    setActiveRide(null);
    setChatMessages([]);
    setSosAlert(null);
    setDrivers(INITIAL_DRIVERS);
    addLog('System state restored to factory defaults.', 'dispatch');
  };

  // Quick Demo Trigger
  const quickDemoHail = () => {
    const pickup = ADDIS_LOCATIONS[1]; // Meskel Sq
    const destination = ADDIS_LOCATIONS[0]; // Bole Airport
    createCustomerRide({
      pickup,
      destination,
      tier: 'standard',
      paymentMethod: 'telebirr',
      customerName: 'Alemayehu G.',
      customerPhone: '0911 234 567',
    });
  };

  // Smooth live telematics loop: moves car towards pickup or destination
  useEffect(() => {
    if (!activeRide || !activeRide.driverId) return;

    const interval = setInterval(() => {
      setDrivers((prev) =>
        prev.map((d) => {
          if (d.id !== activeRide.driverId) return d;

          const target =
            activeRide.status === 'arriving'
              ? activeRide.pickup
              : activeRide.status === 'in_progress'
              ? activeRide.destination
              : null;

          if (!target) return d;

          // Step coordinates slightly toward target
          const step = 0.0006;
          const latDiff = target.lat - d.location.lat;
          const lngDiff = target.lng - d.location.lng;
          const dist = Math.sqrt(latDiff * latDiff + lngDiff * lngDiff);

          if (dist < 0.0005) {
            // Already there
            return d;
          }

          const angleRad = Math.atan2(latDiff, lngDiff);
          const headingDeg = (angleRad * 180) / Math.PI;

          const newLat = d.location.lat + (latDiff / dist) * Math.min(step, dist);
          const newLng = d.location.lng + (lngDiff / dist) * Math.min(step, dist);

          return {
            ...d,
            location: {
              lat: newLat,
              lng: newLng,
              heading: (headingDeg + 360) % 360,
            },
          };
        })
      );
    }, 1200);

    return () => clearInterval(interval);
  }, [activeRide]);

  return (
    <RideControlContext.Provider
      value={{
        viewMode,
        setViewMode,
        language,
        setLanguage,
        soundEnabled,
        setSoundEnabled,
        activeRide,
        allRides,
        drivers,
        currentDriver,
        surgeMultiplier,
        setSurgeMultiplier,
        logs,
        chatMessages,
        sosAlert,
        createCustomerRide,
        cancelRide,
        driverAcceptRide,
        driverDeclineRide,
        driverMarkArrived,
        driverStartTrip,
        driverCompleteTrip,
        rateAndFinishRide,
        toggleDriverOnline,
        withdrawTelebirr,
        sendChatMessage,
        triggerSOS,
        dismissSOS,
        resetAll,
        quickDemoHail,
      }}
    >
      {children}
    </RideControlContext.Provider>
  );
};

export const useRideControl = () => {
  const context = useContext(RideControlContext);
  if (!context) {
    throw new Error('useRideControl must be used within a RideControlProvider');
  }
  return context;
};
